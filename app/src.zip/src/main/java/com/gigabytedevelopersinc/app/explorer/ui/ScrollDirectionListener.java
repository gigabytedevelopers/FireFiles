package com.gigabytedevelopersinc.app.explorer.ui;

public interface ScrollDirectionListener {
    void onScrollDown();
    void onScrollUp();
}